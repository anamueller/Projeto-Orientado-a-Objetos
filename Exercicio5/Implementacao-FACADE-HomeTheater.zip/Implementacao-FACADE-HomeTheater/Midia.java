public abstract class Midia {
    private int duracao;
    private String nome;

    public void getDuracao(){
        return duracao;
    }

    public void getNome(){
        return nome;
    }
}



