public class DVDPlayer extends AparelhoMidia {
    
    private Midia midia;

    public void reproduzir(Midia midia){
        this.midia = midia;
    }

    public Midia getMidia(){
        return midia;
    }

}

