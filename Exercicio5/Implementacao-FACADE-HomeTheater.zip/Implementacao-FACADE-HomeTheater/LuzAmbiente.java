public class LuzAmbiente {
    // 0 -> apagada
    // 1 -> acesa
    private int status = 0;

    public void acender(){
        if (status == 0) {
            status = 1;
        }
    }

    public void apagar(){
        if (status == 1) {
            status = 0;
        }
    }
}



