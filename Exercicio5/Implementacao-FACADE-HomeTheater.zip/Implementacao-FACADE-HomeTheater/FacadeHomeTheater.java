public class FacadeHomeTheater {
    private DVDPlayer dvdPlayer;
    private Amplificador amplificador;
    private Sintonizador sintonizador;
    private TelaProjecao tela;
    private CDPlayer cdPlayer;
    private MaquinaPipoca maqPipoca;
    private MaquinaRefrigerante maqRefrigerante;
    private LuzAmbiente luz;
    private Projetor projetor;


    public FacadeHomeTheater (DVDPlayer dvdPlayer, Amplificador amplificador, Sintonizador sintonizador, TelaProjecao tela, 
        CDPlayer cdPlayer, MaquinaPipoca maqPipoca, MaquinaRefrigerante maqRefrigerante, LuzAmbiente luz, Projetor projetor) {

        this.dvdPlayer = dvdPlayer;
        this.amplificador = aplificador;
        this.sintonizador = sintonizador;
        this.tela = tela;
        this.cdPlayer = cdPlayer;
        this.maqPipoca = maqPipoca;
        this.maqRefrigerante = maqRefrigerante;
        this.luz = luz;
        this.projetor = projetor;

    }

    public void assistirMidia (Midia midia) {
        maqRefrigerante.ligar();
        maqRefrigerante.fazer();

        maqPipoca.ligar();
        maqPipoca.cozinhar();

        luz.apagar();

        tela.descer();

        dvdPlayer.ligar();
        dvdPlayer.reproduzir(midia);

        projetor.ligar();
        projetor.acessarMidia(dvdPlayer);

        amplificador.ligar();
        amplificador.acessarMidia(dvdPlayer);
        amplificador.ajustarVolume(50);

    }

    public void ouvirCD (CD cd) {
        
        cdPlayer.ligar();
        cdPlayer.reproduzir(cd);

        amplificador.ligar();
        amplificador.acessarMidia(cdPlayer);
        amplificador.ajustarVolume(50);

    }

    public void encerrarMidia () {
        maqRefrigerante.desligar();
        maqPipoca.desligar();
        luz.acender();
        tela.subir();
        projetor.desligar();
        amplificador.desligar();
        dvdPlayer.ejetar();
        dvdPlayer.desligar();
    }

    public void encerrarCD () {
        amplificador.desligar();
        cdPlayer.ejetar();
        cdPlayer.desligar();
    }
    
}
