public class Sintonizador {
    // 0 -> desligado
    // 1 -> ligado
    private int status = 0;

    public void ligar() {
        if (status == 0){
            status = 1;
        }
    }
    
    public void desligar() {
        if (status == 1){
            status = 0;
        }
    }

    public float encontrarFrequencia(){
        ...
        return frequencia;
    }
 
}


