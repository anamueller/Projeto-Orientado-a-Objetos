public class Projetor {
    // 0 -> desligado
    // 1 -> ligado
    private int status = 0;
    private Midia reproducao;

    public void ligar() {
        if (status == 0){
            status = 1;
        }
    }
    
    public void desligar() {
        if (status == 1){
            status = 0;
        }
    }

    public void acessarMidia(AparelhoMidia midia) {
        reproducao = midia.getMidia();
    }

}



