public class DVD extends Midia {
   private String diretor;
   private String estúdio;
}




