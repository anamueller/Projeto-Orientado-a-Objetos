public class CDPlayer extends AparelhoMidia {

    private CD cd;

    public void reproduzir(CD cd){
        this.cd = cd;
    }

    public CD getMidia(){
        return cd;
    }

}







