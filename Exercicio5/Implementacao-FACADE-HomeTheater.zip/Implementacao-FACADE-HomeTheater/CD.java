public class CD extends Midia {
    private String interprete;
    private String compositor;
}





