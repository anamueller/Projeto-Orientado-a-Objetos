public class Tela {
    // 0 -> guardada
    // 1 -> exposta
    private int status = 0;

    public void subir(){
        if (status == 1) {
            status = 0;
        }
    }

    public void descer(){
        if (status == 0) {
            status = 1;
        }
    }
}


