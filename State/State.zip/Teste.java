package State;

public class Teste {
    public static void main(String[] args){
        EstadoVivo testando = new EstadoVivo();
        testando.miar();
    }
}
