package State;

public class EstadoQuantico implements Estado {
    public void miar() {
        System.out.println("Hello World!");
    }
}
