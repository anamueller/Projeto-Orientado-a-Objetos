package State;

public class EstadoVivo implements Estado {

    public void miar() {
        System.out.println("Meaaaooww!!");
    }
}