package State;

public interface Estado {
    void miar();
}