package State;

public class EstadoMorto implements Estado {
    public void miar() {
        System.out.println("Morri!");
    }
}