package Exercicio9;

public abstract class AlgarismoFlyweight{
    public abstract void operacao(int num);

    public abstract int getNum();
}