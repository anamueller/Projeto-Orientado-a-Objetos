package Exercicio11;

public interface CriadorShape{
    Shape criaShape();
}