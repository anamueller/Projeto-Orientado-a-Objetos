package Exercicio11;

public interface Shape {
    void area();
}
