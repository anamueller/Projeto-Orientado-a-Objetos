package Exercicio11;

public class Circulo implements Shape{

    @Override
    public void area() {
        System.out.printf("Area Calculada");       
    }
    
}
