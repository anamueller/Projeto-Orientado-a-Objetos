package Strategy;

public class DiadaSemana implements Estrategia{

    @Override
    public void DiaDaSemana() {
        System.out.printf("Aguenta que logo o final de semana chega!");
        
    }
    
}
