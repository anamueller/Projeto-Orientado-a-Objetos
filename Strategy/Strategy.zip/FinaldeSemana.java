package Strategy;

public class FinaldeSemana implements Estrategia {

    @Override
    public void DiaDaSemana() {
        System.out.printf("É final de semana, comemore!");
    }
}