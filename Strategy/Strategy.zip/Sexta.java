package Strategy;

public class Sexta implements Estrategia{

    @Override
    public void DiaDaSemana() {
        System.out.printf("É sexta feira, hora de festar!");
    }
    
}
