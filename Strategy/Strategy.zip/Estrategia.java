package Strategy;

public interface Estrategia {
    void DiaDaSemana();
}