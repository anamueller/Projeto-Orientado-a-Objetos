package Decorator;
  
public class Texto2 extends Texto{

  public Texto2(String s){
    texto = s;
  }
}