package Decorator;
  
public abstract class Texto {
  String texto;
 
  public String getTexto() {
    return texto;
  }
}