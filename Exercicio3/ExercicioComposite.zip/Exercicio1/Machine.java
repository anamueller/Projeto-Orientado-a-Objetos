public abstract class Machine extends MachineComponent {
    
    public int getMachineCount() {
        return 1;
    }
}