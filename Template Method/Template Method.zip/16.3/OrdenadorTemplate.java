import java.util.ArrayList;

public abstract class OrdenadorTemplate {
    public abstract boolean imprimir()();
 
    
}