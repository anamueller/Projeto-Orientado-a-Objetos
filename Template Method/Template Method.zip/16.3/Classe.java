public class Classe {
    String NomeDaClasse;
    String mensagem;
 
    public Classe(String n, String m) {
        this.NomeDaClasse = n;
        this.mensagem = m;
    }
}