public class Palavra {
    String word;
 
    public Palavra(String p) {
        this.word = p;
    }
}