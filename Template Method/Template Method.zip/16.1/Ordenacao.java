public enum Ordenacao {
    porLetra
}
