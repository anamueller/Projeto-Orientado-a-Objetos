package Exercicio8;

public abstract class Mediador {

    public void enviaMensagem(){
        System.out.println("Mensagem recebida");
    }
}
