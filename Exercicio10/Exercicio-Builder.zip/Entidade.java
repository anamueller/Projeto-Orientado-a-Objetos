package Exercicio10;

public class Entidade {
    int identidade;
    String nome;
}
